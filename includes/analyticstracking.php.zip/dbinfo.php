<?php

  $server = "localhost";
  $database = "rotar634_rct";
  $user_name = "rotar634_rct";
  $password = "=_AAbNX4chn~9iMm*}";

?>
